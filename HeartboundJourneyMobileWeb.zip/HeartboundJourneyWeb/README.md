# The Heartbound Journey — Mobile Browser Edition

A mobile-friendly 2D RPG prototype built with HTML Canvas, CSS, and JavaScript.
It uses the uploaded character sprite sheet, split into directional walking and idle frames.

## Run it
- Simplest: open `index.html` in a modern browser.
- For best mobile/PWA behavior, serve this folder from a local or hosted static web server.
- To put it online, upload the folder contents to a static host such as GitHub Pages or Netlify.
- On Android Chrome, open the hosted URL, then use the browser menu's **Add to Home screen** option.

## Controls
- Touch D-pad: hold to walk / dodge.
- TALK: talk to nearby NPCs or search for an encounter.
- Battle actions: tap FIGHT, ACT, ITEM, or MERCY.
- Pause: top-right pause button.
- Desktop testing: WASD or arrow keys; ENTER interacts; ESC pauses.

## Prototype features
- Scrolling top-down tile-map clearing
- Two NPCs and dialogue
- Directional idle/walk sprite animation
- Multi-touch virtual D-pad and interaction button
- Random enemy encounters
- Four battle actions and a simple dodge phase
- HP, EXP, leveling, and pause state

## Notes
This is a prototype rather than a finished game. The sprite sheet's original background is automatically separated during frame preparation; inspect the PNG frames if you notice cutout artifacts. The source JavaScript is intentionally unbundled so it is easy to edit.
