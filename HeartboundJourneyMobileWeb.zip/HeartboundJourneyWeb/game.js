(() => {
"use strict";
const canvas=document.getElementById("game"), ctx=canvas.getContext("2d");
ctx.imageSmoothingEnabled=false;
const W=960,H=640,T=48, cols=20,rows=14;
const keys={up:false,down:false,left:false,right:false,interact:false};
const map=Array.from({length:rows},(_,y)=>Array.from({length:cols},(_,x)=>(x===0||y===0||x===cols-1||y===rows-1)?1:0));
for(let x=3;x<8;x++)map[3][x]=1;
for(let y=3;y<7;y++)map[y][12]=1;
for(let x=13;x<18;x++)map[9][x]=1;
const player={x:5.5,y:6.5,speed:2.7,face:"down",moving:false,hp:20,maxHp:20,level:1,exp:0};
const npcs=[{x:7.5,y:6.5,name:"Mira",line:"The old stones hum when the stars come out."},{x:14.5,y:5.5,name:"Pip",line:"I heard something moving beneath the roots."}];
const sprites={};
const frameCounts={walk_down:5,walk_up:6,walk_left:6,walk_right:6,idle_down:3,idle_up:3,idle_left:3,idle_right:3};
for(const [group,count] of Object.entries(frameCounts)){
  sprites[group]=[];
  for(let i=0;i<count;i++){const img=new Image();img.src=`assets/sprites/${group}_${i}.png`;sprites[group].push(img);}
}
let state="world",tick=0,message="Explore the clearing. Find someone to talk to.",toastUntil=performance.now()+5000;
let enemy="Mossling",enemyHp=24,enemyMax=24,menu=0,dodgeTicks=0,heart={x:.5,y:.64};
const actions=["FIGHT","ACT","ITEM","MERCY"];
function say(s,ms=4000){message=s;toastUntil=performance.now()+ms}
function blocked(x,y){
 const tx=Math.floor(x),ty=Math.floor(y);
 if(tx<1||ty<1||tx>=cols-1||ty>=rows-1||map[ty][tx]===1)return true;
 return npcs.some(n=>Math.abs(n.x-x)<.62&&Math.abs(n.y-y)<.62);
}
function interact(){
 const near=npcs.find(n=>Math.abs(n.x-player.x)<1.15&&Math.abs(n.y-player.y)<1.15);
 if(near){say(near.name+": "+near.line,5000);return}
 if(Math.random()<.25){enemy=Math.random()<.5?"Mossling":"Cave Moth";enemyHp=enemyMax=24;state="battle";say(enemy+" approaches!")}
 else say("You look around, but nothing happens.",2200);
}
function update(){
 tick++;
 if(state==="world"){
  let dx=0,dy=0;
  if(keys.left){dx--;player.face="left"}if(keys.right){dx++;player.face="right"}
  if(keys.up){dy--;player.face="up"}if(keys.down){dy++;player.face="down"}
  player.moving=!!(dx||dy);
  if(player.moving){const l=Math.hypot(dx,dy);dx=dx/l*player.speed/48;dy=dy/l*player.speed/48;if(!blocked(player.x+dx,player.y))player.x+=dx;if(!blocked(player.x,player.y+dy))player.y+=dy}
 }else if(state==="dodge"){
  if(keys.left)heart.x-=.012;if(keys.right)heart.x+=.012;if(keys.up)heart.y-=.012;if(keys.down)heart.y+=.012;
  heart.x=Math.max(.05,Math.min(.95,heart.x));heart.y=Math.max(.05,Math.min(.95,heart.y));dodgeTicks++;
  if(dodgeTicks%30===0&&Math.random()<.65)player.hp=Math.max(0,player.hp-1);
  if(dodgeTicks>180){state="battle";dodgeTicks=0;heart={x:.5,y:.64};say("Your turn! Choose an action.");if(player.hp<=0){player.hp=player.maxHp;state="world";say("You wake up at the clearing.")}}
 }
}
function rect(x,y,w,h,color){ctx.fillStyle=color;ctx.fillRect(x,y,w,h)}
function text(s,x,y,size=16,color="#fff",align="left"){ctx.fillStyle=color;ctx.font=`bold ${size}px monospace`;ctx.textAlign=align;ctx.fillText(s,x,y)}
function panel(x,y,w,h){ctx.fillStyle="#fff";ctx.fillRect(x,y,w,h);ctx.fillStyle="#050509";ctx.fillRect(x+4,y+4,w-8,h-8)}
function drawWorld(){
 const ox=480-(player.x*T+T/2),oy=300-(player.y*T+T/2);
 for(let y=0;y<rows;y++)for(let x=0;x<cols;x++){
  const sx=ox+x*T,sy=oy+y*T;rect(sx,sy,T+1,T+1,(x+y)%2?"#316146":"#36694c");
  if(map[y][x]){rect(sx,sy,T,T,"#3e3741");ctx.strokeStyle="#5c535c";ctx.strokeRect(sx+3,sy+3,T-6,T-6)}
 }
 ctx.fillStyle="#2d6491";ctx.beginPath();ctx.roundRect(ox+15*T,oy+2*T,3*T,2*T,22);ctx.fill();
 for(const n of npcs){const x=ox+n.x*T,y=oy+n.y*T;ctx.fillStyle="#5a9678";ctx.beginPath();ctx.arc(x,y-6,15,0,Math.PI*2);ctx.fill();rect(x-16,y+7,32,24,"#23372d");text(n.name.toUpperCase(),x,y-29,10,"#fff","center")}
 const key=(player.moving?"walk_":"idle_")+player.face,frames=sprites[key]||[],idx=player.moving?Math.floor(tick/8)%frames.length:Math.floor(tick/28)%frames.length,img=frames[idx];
 if(img&&img.complete&&img.naturalWidth){ctx.imageSmoothingEnabled=false;ctx.drawImage(img,432,243,96,114)}else{ctx.fillStyle="#f0a0b4";ctx.beginPath();ctx.arc(480,290,20,0,Math.PI*2);ctx.fill()}
 panel(12,12,260,62);text(`HP ${player.hp}/${player.maxHp}    LV ${player.level}`,26,39,16);text(`EXP ${player.exp}`,26,60,14,"#ccc");
 panel(300,12,648,48);text(message.length>76?message.slice(0,73)+"...":message,320,42,14);
}
function drawButton(x,y,label,active=false){ctx.fillStyle=active?"#b96f42":"#4b4155";ctx.beginPath();ctx.roundRect(x-42,y-27,84,54,12);ctx.fill();ctx.strokeStyle="#fff";ctx.lineWidth=2;ctx.stroke();text(label,x,y+6,label.length>3?13:22,"#fff","center")}
function drawBattle(){
 rect(0,0,W,H,"#11121e");text(enemy,480,92,30,"#fff","center");
 ctx.strokeStyle="#fff";ctx.strokeRect(370,112,220,14);rect(371,113,218*Math.max(0,enemyHp)/enemyMax,12,"#be4b5a");
 if(state==="battle"){
  panel(85,160,790,280);text("* "+message,480,218,17,"#fff","center");text(`HP ${player.hp}/${player.maxHp}`,480,275,18,"#fff","center");
  actions.forEach((a,i)=>drawButton(135+i*185,370,a,menu===i));text("Tap an action to continue",480,470,15,"#ccc","center");
 }else{
  ctx.strokeStyle="#fff";ctx.strokeRect(310,285,340,215);ctx.fillStyle="#ff4664";ctx.beginPath();ctx.arc(310+heart.x*340,285+heart.y*215,9,0,Math.PI*2);ctx.fill();
  for(let i=0;i<6;i++){ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(330+(i*49+(tick*3)%280)%300,300+(i*31+tick*2)%185,5,0,Math.PI*2);ctx.fill()}
  text("DODGE THE SPARKS",480,250,20,"#fff","center");text("Hold the direction controls to move",480,550,15,"#ddd","center");
 }
}
function draw(){
 ctx.clearRect(0,0,W,H);if(state==="world"||state==="pause")drawWorld();else drawBattle();
 if(state==="pause"){rect(0,0,W,H,"rgba(0,0,0,.65)");panel(330,240,300,140);text("PAUSED",480,292,30,"#fff","center");text("Tap RESUME to continue",480,335,16,"#fff","center")}
}
function loop(){update();draw();requestAnimationFrame(loop)}
function choose(i){
 if(state!=="battle")return;menu=i;
 if(i===0){enemyHp-=8;say("You strike!")}
 if(i===1)say("You observe "+enemy+". It seems nervous.");
 if(i===2){player.hp=Math.min(player.maxHp,player.hp+6);say("You eat a healing snack.")}
 if(i===3){enemyHp=0;say("You show mercy. The enemy leaves.")}
 if(enemyHp<=0){player.exp+=12;if(player.exp>=20){player.exp-=20;player.level++;player.maxHp+=4;player.hp=player.maxHp}state="world";say("Victory! You gained 12 EXP.");return}
 state="dodge";dodgeTicks=0;say("Avoid the incoming sparks!");
}
function setKey(k,v){if(k in keys)keys[k]=v}
document.querySelectorAll("[data-key]").forEach(btn=>{
 const k=btn.dataset.key;
 const down=e=>{e.preventDefault();setKey(k,true);btn.classList.add("active");try{btn.setPointerCapture(e.pointerId)}catch(_){}};
 const up=e=>{e.preventDefault();setKey(k,false);btn.classList.remove("active")};
 btn.addEventListener("pointerdown",down);btn.addEventListener("pointerup",up);btn.addEventListener("pointercancel",up);btn.addEventListener("lostpointercapture",up);
});
const talk=document.getElementById("talk");
talk.addEventListener("pointerdown",e=>{e.preventDefault();if(state==="world")interact();else if(state==="pause")state="world";});
document.getElementById("pause").addEventListener("pointerdown",e=>{e.preventDefault();state=state==="pause"?"world":state==="world"?"pause":state});
canvas.addEventListener("pointerdown",e=>{
 if(state==="battle"){
  const r=canvas.getBoundingClientRect(),x=(e.clientX-r.left)*W/r.width,y=(e.clientY-r.top)*H/r.height;
  if(y>325&&y<420){const i=Math.max(0,Math.min(3,Math.floor((x-70)/185)));choose(i)}
  else if(y>450&&state==="battle")choose(menu);
 }else if(state==="pause")state="world";
});
window.addEventListener("keydown",e=>{
 const mapKey={ArrowUp:"up",w:"up",ArrowDown:"down",s:"down",ArrowLeft:"left",a:"left",ArrowRight:"right",d:"right"};
 const k=mapKey[e.key];if(k){e.preventDefault();setKey(k,true)}
 if(e.key==="Enter"||e.key===" "){e.preventDefault();if(state==="world")interact();else if(state==="battle")choose(menu);else if(state==="pause")state="world"}
 if(e.key==="Escape")state=state==="pause"?"world":state==="world"?"pause":state;
 if(state==="battle"&&(e.key==="ArrowLeft"||e.key==="ArrowRight"))menu=(menu+(e.key==="ArrowRight"?1:3))%4;
});
window.addEventListener("keyup",e=>{const mapKey={ArrowUp:"up",w:"up",ArrowDown:"down",s:"down",ArrowLeft:"left",a:"left",ArrowRight:"right",d:"right"};if(mapKey[e.key])setKey(mapKey[e.key],false)});
document.addEventListener("visibilitychange",()=>{if(document.hidden)Object.keys(keys).forEach(k=>keys[k]=false)});
loop();
})();